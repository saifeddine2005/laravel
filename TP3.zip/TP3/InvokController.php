<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InvokController extends Controller
{
    /**
     * Handle the incoming request.
     */
    public function __invoke($page)
    {
        if (in_array($page,['Acceuil','Contact','Presentation']))
        return view(''.$page);
        abort(404);
    }
}
