<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InscriController extends Controller
{
    function index($nom=null,$prenom=null,$sexe=null,$email=null){
        return view('InscriView',compact('nom','prenom','sexe','email'));
    }

    function Afficher(Request $req){
        $nom=$req->input('nom');
        $prenom=$req->input('prenom');
        $sexe=$req->input('sexe');
        $email=$req->input('email');

        return redirect()->route('form',compact('nom','prenom','sexe','email'));
    }
}
