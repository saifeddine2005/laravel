<h1>formulaire d'inscription</h1>

<form action="{{route('info')}}" method='post'>
    @csrf
    <input type='text' name='prenom' />
    <input type='text' name='nom' />
    <select name='sexe' >
        <option value='homme'>Homme</option>
        <option value='femme'>Femme</option>
</select>
<input type='email' name='email' />
<input type='submit' value='OK' />
</form>
<h5>Votre prenom {{$prenom ?? ''}}</h5>
<h5>Votre nom {{$nom ?? ''}}</h5>
<h5>Vous etes {{$sexe ?? ''}}</h5>
<h5>Votre email {{$email ?? ''}}</h5>