<h1>Calculatrice</h1>
<form action="{{route('calculer')}}" method='post'>
    @csrf
    <input type='number' name='nbr1' /><br>

    <select name='operation'>
        <option value='+'>+</option>
        <option value='-'>-</option>
        <option value='x'>x</option>
        <option value='/'>/</option>
    </select><br>
    <input type='number' name='nbr2' /><br>
    <input type='submit' value='OK' />
    <h2>Le resultat est : {{$result ?? ""}}</h2>

</form>
