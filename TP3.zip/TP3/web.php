<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\CalController;
use App\Http\Controllers\InscriController;
use App\Http\Controllers\InvokController;

Route::get('/', function () {
    return view('welcome');
});


Route::get('/', function () {
    return view('welcome');
});

Route::get('/home/{result?}',[CalController::class,'index'])->name('home');

Route::post("/calculer", [CalController::class,'Calculer'])->name('calculer');


//ex2

Route::get('/form/{nom?}/{prenom?}/{sexe?}/{email?}',[InscriController::class,'index'])->name('form');

Route::post('/info',[InscriController::class,'Afficher'])->name('info');

//ex3

Route::get('/{page}',InvokController::class);