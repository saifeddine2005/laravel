<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CalController extends Controller
{
    function index($result=null){
        return view('calculatriceView',['result'=>$result]);
    }
    function Calculer(Request $request){
        $nbr1=$request->input('nbr1');
    $nbr2=$request->input('nbr2');
    $op=$request->input('operation');
    $result="";

    switch($op){
        case '+':
            $result=$nbr1+$nbr2;
            break;
        case '-':
            $result=$nbr1-$nbr2;
            break;
        case 'x':
            $result=$nbr1*$nbr2;
            break;
        case '/':
            $result=$nbr1/$nbr2;
            break;
    };
    return redirect()->route("home", ["result"=>$result]); 
    }
}
