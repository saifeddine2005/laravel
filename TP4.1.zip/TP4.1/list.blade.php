<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>Liste des stagiaires</title>
</head>
<body style="text-align:center">
    <h2>Liste des notes</h2>
    <form action='/notes/show' method='post'>
        @csrf
        <input type='text' name='recherche' placeholder='Entrer un nom' />
        <input type='submit' value='Chercher' />
    </form>
    @isset($notes)
    <table class='table'>
        <tr>
            <th>Nom</th>
            <th>Note</th>
        </tr>
        @forelse ($notes as $nom=>$note)
        @if(isset($statistique))
            @if($note>10)
                <tr class='table-success' >
            @elseif($note>=8 && $note<=10)
                <tr class='table-warning' >
            @else
                <tr class='table-danger' >
            @endif
        @elseif(isset($decorate))
            @if($loop->odd)
                <tr class='table-dark'>
            @elseif($loop->even)
                <tr class='table-light'>
            @endif
        @else
            <tr>
        @endif
            <td>{{$nom}}</td>
            <td>{{$note}}</td>
        </tr>
        @empty
        <tr>
            <td colspan='2' class='bg-warning'>pas de resultat</td>
        </tr>
        @endforelse
    </table>
    @endisset
</body>
</html>