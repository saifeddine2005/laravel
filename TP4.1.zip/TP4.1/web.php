<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\NotesController;


Route::get('/notes',[NotesController::class,'all'])->name('all');
Route::get('/notes/statistique',[NotesController::class,'statistique']);
Route::get('/notes/decorate',[NotesController::class,'decorate']);
Route::post('/notes/show',[NotesController::class,'show']);