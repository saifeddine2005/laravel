<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;

class NotesController extends Controller{
    
    public function all(){
        if( session()->has('result') ){ 
            $result= session('result');
            $notes= $result;
        }
        else{
            $notes = [
                "Mohamed Alaoui" => 16,
                "Ahmed Bennani" => 14,
                "Rachida Kich" => 6,
                "Aicha Saaoudi" => 19,
                "Noura Alaoui" => 7,
                "Samar Rhaoussi" => 13,
                "Aicha Siraj" => 10,
                "Samiha Hakim" => 9,
                "Mohamed Rami" => 17,
                "Sami Tazi" => 7,
                "Noura Tazi" => 14,
            ];
            arsort($notes);
        }
        return view('list',compact('notes'));
    }

    public function statistique(){
        $notes = [
            "Mohamed Alaoui" => 16,
            "Ahmed Bennani" => 14,
            "Rachida Kich" => 6,
            "Aicha Saaoudi" => 19,
            "Noura Alaoui" => 7,
            "Samar Rhaoussi" => 13,
            "Aicha Siraj" => 10,
            "Samiha Hakim" => 9,
            "Mohamed Rami" => 17,
            "Sami Tazi" => 7,
            "Noura Tazi" => 14,
        ];
        arsort($notes);
        $statistique=True;
        return view('list',compact('notes','statistique'));
    }

    public function show(Request $req){
        $nom=$req->input("recherche");
        $notes = [
            "Mohamed Alaoui" => 16,
            "Ahmed Bennani" => 14,
            "Rachida Kich" => 6,
            "Aicha Saaoudi" => 19,
            "Noura Alaoui" => 7,
            "Samar Rhaoussi" => 13,
            "Aicha Siraj" => 10,
            "Samiha Hakim" => 9,
            "Mohamed Rami" => 17,
            "Sami Tazi" => 7,
            "Noura Tazi" => 14,
        ];
        $result=[];
        foreach($notes as $key=>$value){
            $key=strtolower($key);
            $nom=strtolower($nom);
            if(str_contains($key,$nom)){
                $result[$key]=$value;
            }
            $result=empty($result) ? []:$result;
        }
        return redirect()->route("all")->with('result',$result);

    }
    public function decorate(){
        $notes = [
            "Mohamed Alaoui" => 16,
            "Ahmed Bennani" => 14,
            "Rachida Kich" => 6,
            "Aicha Saaoudi" => 19,
            "Noura Alaoui" => 7,
            "Samar Rhaoussi" => 13,
            "Aicha Siraj" => 10,
            "Samiha Hakim" => 9,
            "Mohamed Rami" => 17,
            "Sami Tazi" => 7,
            "Noura Tazi" => 14,
        ];
        $decorate=true;
        return  view("list", compact("decorate", "notes"));
    }  
}